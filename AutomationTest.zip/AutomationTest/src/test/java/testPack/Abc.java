package testPack;

public class Abc {

	public static void main(String[] args) {
		
		System .setProperty("webdriver.chrome.driver\", \"C:\\\\Users\\\\user\\\\eclipse-workspace\\\\AutomationTest\\\\Drivers\\\\chromedriver.exe");
		Webdriver driver=new Chrome 
		
		// TODO Auto-generated method stub
       
	}

}

package testPack;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class OpenBrowser {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\user\\eclipse-workspace\\AutomationTest\\Drivers\\chromedriver.exe");
		 
		// Initialize browser
		WebDriver driver=new ChromeDriver();
		 
		// Open facebook
		driver.get("https://www.irctc.co.in/nget/train-search");
		 
		// Maximize browser
		 
		driver.manage().window().maximize();
		
		driver.findElement(By.id("email")).sendKeys("vsingh123");
		driver.findElement(By.id("pass")).sendKeys("vsingh123");

		driver.findElement(By.id("pass")).sendKeys("");
		driver.findElement(By.xpath("//*[@id='u_0_i']")).sendKeys("");
	}

}
